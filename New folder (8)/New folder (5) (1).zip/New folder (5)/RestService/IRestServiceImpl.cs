﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace RestService
{
    
    
    [ServiceContract]
    public interface IRestServiceImpl:IService1
    {
        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Xml,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "xml/{id}")]
        string XMLData(string id);

        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "json/{id}/{name}")]
        string JSONData(string id,string name);


        [OperationContract]
        [WebGet(UriTemplate = "sp", BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json)]
      
        string sps();
      
    }
}