﻿
namespace RestService
{
    public class RestServiceImpl : IRestServiceImpl,IService1
    {
        #region IRestServiceImpl Members

        public string XMLData(string id)
        {
            return "You requested product " + id;
        }

        public string JSONData(string id,string name)
        {
            return "You requested product " + id + "=="+ name;
        }
        public string sps()
        {
            return "Saurabh Pratap Singh";
            
        }

        #endregion

        public string DoWork()
        {

            // throw new System.NotImplementedException();
            return "mayank";
        }
    }
}